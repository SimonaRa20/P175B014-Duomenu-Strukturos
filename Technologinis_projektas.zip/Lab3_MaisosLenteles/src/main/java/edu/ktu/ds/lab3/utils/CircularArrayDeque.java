package edu.ktu.ds.lab3.utils;

public class CircularArrayDeque <E> implements Deque<E>{
    int elementsCount;
    private E[] array;
    private int size;
    private static int front;
    private static int rear;

    public CircularArrayDeque(){
        array = (E[]) new Object[8];
        size = 8;
        front = -1;
        rear = -1;
        elementsCount = 0;
    }

    public void clean(){
        array = (E[]) new Object[8];
        elementsCount = 0;
        front = -1;
        rear = -1;
        size = 8;
    }

    @Override
    public void addFirst(E item){
        if(front == -1){
            front = 0;
            rear = 0;
        }
        else{
            if(front == 0){
                if(array[size - 1] == null){
                    front = size - 1;
                }
                else{
                    resize(size*2);
                    front = size - 1;
                }
            }
            else{
                if(array[front-1] == null){
                    front = front -1;
                }
                else{
                    resize(size*2);
                    front = size - 1;
                }
            }
        }
        array[front] = item;
        elementsCount++;
    }

    private void resize(int capacity) {
        E[] copy = (E[]) new Object[capacity];
        int index = front;
        int count = 0;
        while(index != rear){
            copy[count++] = array[index];
            index++;
            if(index == size){
                index = 0;
            }
        }
        copy[count] = array[rear];
        front = 0;
        rear = size - 1;
        size = capacity;
        array = copy;
    }

    @Override
    public void addLast(E item){
        if(front == -1){
            front = 0;
            rear = 0;
        }
        else{
            if(rear == size - 1){
                if(array[0] == null){
                    rear = 0;
                }
                else{
                    resize(size*2);
                    rear = rear + 1;
                }
            }
            else{
                if(array[rear + 1] == null){
                    rear = rear + 1;
                }
                else{
                    resize(size*2);
                    rear = rear + 1;
                }
            }
        }
        array[rear] = item;
        elementsCount++;
    }

    @Override
    public E removeFirst(){
        E item = null;
        if(front == size - 1){
            item = array[front];
            array[front] = null;
            front = 0;
            if(array[front] == null){
                front = -1;
                rear = -1;
            }
        }
        else{
            item = array[front];
            array[front] = null;
            front = front + 1;
            if(array[front] == null){
                front = -1;
                rear = -1;
            }
        }
        if(item != null && elementsCount > 0){
            elementsCount--;
        }
        return item;
    }

    @Override
    public E removeLast(){
        E item = null;
        if(rear == 0){
            item = array[rear];
            array[rear] = null;
            rear = size - 1;
            if(array[rear] == null){
                front = -1;
                rear = -1;
            }
        }
        else{
            item = array[rear];
            array[rear] = null;
            rear = rear - 1;
            if(array[rear] == null){
                front = -1;
                rear = -1;
            }
        }
        if(item != null && elementsCount > 0){
            elementsCount--;
        }
        return item;
    }

    @Override
    public E getFirst(){
        if(front != -1)
            return array[front];
        else
            return null;
    }

    @Override
    public E getLast(){
        if(rear != -1)
            return array[rear];
        else
            return null;
    }

    @Override
    public void println(String title) {
        Ks.oun("========" + title + "=======");
        println();
        Ks.oun("======== Sąrašo pabaiga =======");
    }

    public void println() {  // sąrašas spausdinamas į Ks.oun("");
        int eilNr = 1;
        if (elementsCount == 0) {
            Ks.oun("Sąrašas yra tuščias");
        }
        else {
            int index = front;
            while(index != rear){
                String printData = String.format("%3d: index'as %s %s", eilNr++,index, array[index].toString());
                Ks.oun(printData);
                index++;
                if(index == size){
                    index = 0;
                }
            }
            String printData = String.format("%3d: index'as %s %s", eilNr++,index, array[rear].toString());
            Ks.oun(printData);
        }
        Ks.oun("****** Bendras elementų kiekis yra " + elementsCount);
    }

    public boolean contains(E item)
    {
        boolean flag = false;
        for (int i = front; i != rear; i++){
            if(i == size){
                i = 0;
            }
            if(array[i].equals(item)){
                flag = true;
            }
        }
        if(array[rear].equals(item)){
            flag = true;
        }
        return flag;
    }


}
