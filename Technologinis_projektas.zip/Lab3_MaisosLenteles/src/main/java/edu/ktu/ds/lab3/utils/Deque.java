package edu.ktu.ds.lab3.utils;

import edu.ktu.ds.lab3.demo.Car;

public interface Deque <E>{
    void addFirst(E item);
    void addLast(E item);
    E removeFirst();
    E removeLast();
    E getFirst();
    E getLast();
    void println(String title);
    void clean();
}
