package edu.ktu.ds.lab3.demo;

import edu.ktu.ds.lab3.utils.*;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.BenchmarkParams;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.AverageTime)
@State(Scope.Benchmark)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@Warmup(time = 1, timeUnit = TimeUnit.SECONDS)
@Measurement(time = 1, timeUnit = TimeUnit.SECONDS)
public class Benchmark {

    @State(Scope.Benchmark)
    public static class FullMap {

        List<Car> cars;
        CircularArrayDeque<Car> carsDeque;
        java.util.Deque<Car> carsDequeJava;
        Car car = new Car("Renault Laguna 2011 115900 700");

        @Setup(Level.Iteration)
        public void generateIdsAndCars(BenchmarkParams params) {
            cars = Benchmark.generateCars(Integer.parseInt(params.getParam("elementCount")));
        }

        @Setup(Level.Invocation)
        public void fillCarMap(BenchmarkParams params) {
            carsDeque = new CircularArrayDeque<>();
            putDeque(cars, carsDeque);
            carsDequeJava = new ArrayDeque<>();
            for (int i = 0; i < cars.size(); i++)
            {
                carsDequeJava.addLast(cars.get(i));
            }
        }
    }

    @Param({"10000", "20000", "40000", "80000"})
    public int elementCount;

    List<Car> cars;

    @Setup(Level.Iteration)
    public void generateIdsAndCars() {
        cars = generateCars(elementCount);
    }

    static List<Car> generateCars(int count) {
        return new ArrayList<>(CarsGenerator.generateShuffleCars(count));
    }

//    @org.openjdk.jmh.annotations.Benchmark
//    public Car dequeGetFirst(FullMap fullMap)
//    {
//        return fullMap.carsDeque.getFirst();
//    }
//
//    @org.openjdk.jmh.annotations.Benchmark
//    public Car dequeJavaGetFirst(FullMap fullMap)
//    {
//        return fullMap.carsDequeJava.getFirst();
//    }
//
//    @org.openjdk.jmh.annotations.Benchmark
//    public Car dequeJavaGetLast(FullMap fullMap)
//    {
//        return fullMap.carsDequeJava.getLast();
//    }
//
//    @org.openjdk.jmh.annotations.Benchmark
//    public Car dequeGetLast(FullMap fullMap)
//    {
//        return fullMap.carsDeque.getLast();
//    }
//
    @org.openjdk.jmh.annotations.Benchmark
    public Car dequeJavaRemoveLast(FullMap fullMap)
    {
        return fullMap.carsDequeJava.removeLast();
    }

//    @org.openjdk.jmh.annotations.Benchmark
//    public Car dequeRemoveLast(FullMap fullMap)
//    {
//        return fullMap.carsDeque.removeLast();
//    }
//
//    @org.openjdk.jmh.annotations.Benchmark
//    public Car dequeJavaRemoveFirst(FullMap fullMap)
//    {
//        return fullMap.carsDequeJava.removeFirst();
//    }
//
//    @org.openjdk.jmh.annotations.Benchmark
//    public Car dequeRemoveFirst(FullMap fullMap)
//    {
//        return fullMap.carsDeque.removeFirst();
//    }
//    @org.openjdk.jmh.annotations.Benchmark
//    public void dequeAddFirst(FullMap fullMap)
//    {
//        fullMap.carsDeque.addFirst(fullMap.car);
//    }
//
//    @org.openjdk.jmh.annotations.Benchmark
//    public void dequeJavaAddFirst(FullMap fullMap)
//    {
//        fullMap.carsDequeJava.addFirst(fullMap.car);
//    }

    @org.openjdk.jmh.annotations.Benchmark
    public void dequeAddLast(FullMap fullMap)
    {
        fullMap.carsDeque.addLast(fullMap.car);
    }

    @org.openjdk.jmh.annotations.Benchmark
    public void dequeJavaAddLast(FullMap fullMap)
    {
        fullMap.carsDequeJava.addLast(fullMap.car);
    }

    public static void putDeque(List<Car> cars, CircularArrayDeque<Car> carsDeque) {
        for (int i = 0; i < cars.size(); i++) {
            carsDeque.addLast(cars.get(i));
        }
    }

    public static void main(String[] args) throws RunnerException {
        Options opt = new OptionsBuilder()
                .include(Benchmark.class.getSimpleName())
                .forks(1)
                .build();
        new Runner(opt).run();
    }
}
