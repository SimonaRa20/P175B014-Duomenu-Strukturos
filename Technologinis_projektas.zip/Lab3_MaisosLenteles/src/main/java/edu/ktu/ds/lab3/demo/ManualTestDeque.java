package edu.ktu.ds.lab3.demo;

import edu.ktu.ds.lab3.utils.CircularArrayDeque;
import edu.ktu.ds.lab3.utils.Ks;

import java.util.Locale;

public class ManualTestDeque {
    void execute() throws Exception {
        CircularArrayDeque<Car> circularArray = new CircularArrayDeque<Car>();
        createCarDeque(circularArray, "Testai su CircularArray");
    }

    void createCarDeque(CircularArrayDeque deque, String header) throws Exception {
        Ks.oun(header);
        Car c1 = new Car("Renault", "Laguna", 1997, 50000, 1700);
        Car c2 = new Car("Renault", "Megane", 2001, 20000, 3500);
        Car c3 = new Car("Toyota", "Corolla", 2001, 20000, 8500.8);
        Car c4 = new Car("Renault Laguna 2011 115900 700");
        Car c5 = new Car("Renault Megane 1946 365100 9500");
        Car c6 = new Car("Honda   Civic  2011  36400 80.3");

        deque.addFirst(c1);
        deque.addFirst(c2);
        deque.addFirst(c3);
        deque.println("Pridedame i prieki 3 auto");

        deque.addLast(c4);
        deque.addLast(c5);
        deque.addLast(c6);
        deque.println("Pridedame i gala 3 auto");

        deque.removeFirst();
        deque.removeFirst();
        deque.removeFirst();
        deque.println("Pasalinam 3");

        deque.addFirst(c1);
        deque.addFirst(c2);
        deque.addFirst(c3);
        deque.println("Pridedami 3");

        deque.removeFirst();
        deque.println("Pasalinu pirma esanti deque elementa");

        deque.removeLast();
        deque.println("Pasalinu paskutini esanti deque elementa");

        System.out.println("Pasiimu pirma elementa is saraso: " + deque.getFirst());

        System.out.println("Pasiimu paskutini elementa is saraso: " + deque.getLast());


        deque.clean();
        deque.println("Atliekame clean() metoda");

    }

    public static void main(String... args) throws Exception {
        // suvienodiname skaičių formatus pagal LT lokalę (10-ainis kablelis)
        Locale.setDefault(new Locale("LT"));
        new ManualTestDeque().execute();
    }
}
